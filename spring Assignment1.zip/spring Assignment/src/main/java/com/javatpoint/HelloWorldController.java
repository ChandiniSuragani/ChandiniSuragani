package com.javatpoint;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  

  
@Controller  
public class HelloWorldController {  
      
    @RequestMapping("/hello")  
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) throws IOException 
    {  
    	PrintWriter pw=res.getWriter();
    	res.setContentType("text/html");
    	String a =request.getParameter("t1");
    	String b =request.getParameter("t2");
    	String c =request.getParameter("t3");
    	String d =request.getParameter("t4");
    	String e =request.getParameter("t5");
    	String f =request.getParameter("t6");
    	String g =request.getParameter("t7");
    	String key=request.getParameter("t8");
    	
    	try 
    	{ 
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
    		
    		if(key.equals("Insert")) {
    		
    		PreparedStatement st=con.prepareStatement("insert into  employee values(?,?,?,?,?,?,?)");
    		
    		st.setString(1,a);
    		st.setString(2,b);
    		st.setString(3,c);
    		st.setString(4,d);
    		st.setString(5,e);
    		st.setString(6,f);
    		st.setString(7,g);
    		st.execute();
    		}
    		if(key.equals("update")) {
    			PreparedStatement st=con.prepareStatement("update employee set name=?,pass=?,salary=?,designation=?,phone=?,email=? where empno=?");
        		
        		st.setString(1,b);
        		st.setString(2,c);
        		st.setString(3,d);
        		st.setString(4,e);
        		st.setString(5,f);
        		st.setString(6,g);
        		st.setString(7,a);
        		st.execute();
    			
    		}
    		
    		if(key.equals("Delete")) {
    			PreparedStatement st=con.prepareStatement("delete from employee  where empno=?");
        		
        		st.setString(1,a);
        		st.execute();
    			
    		}
    		
    		if(key.equals("select")) {
    			Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from employee");
				while(rs.next())
				{
					System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7));
					
				}
    			
    		}
    		
    	}
    	catch(Exception ex) 
    	{
    	ex.printStackTrace();
    	}
    	String message = "Successfully Done!";  
        return new ModelAndView("hellopage", "message",message);
        
}
}